import React, { useState } from 'react';
import {
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableOpacity,
  SafeAreaView,
  StatusBar,
  ScrollView,
  Alert,
} from 'react-native';

export default function App() {
  const [authMethod, setAuthMethod] = useState('phone'); // 'phone' | 'email'
  const [countryCode, setCountryCode] = useState('+93'); // پیش‌فرض افغانستان
  const [inputValue, setInputValue] = useState('');
  const [otpCode, setOtpCode] = useState('');
  const [step, setStep] = useState(1); // 1: ورود اطلاعات , 2: کد OTP

  // لیست پیش‌شماره کشورها
  const countryCodes = [
    { label: '🇦🇫 +93 (افغانستان)', code: '+93' },
    { label: '🇦🇪 +971 (امارات)', code: '+971' },
    { label: '🇹🇷 +90 (ترکیه)', code: '+90' },
    { label: '🇮🇷 +98 (ایران)', code: '+98' },
    { label: '🌎 +1 (آمریکا/کانادا)', code: '+1' },
  ];

  const handleSendOTP = async () => {
    if (!inputValue) {
      Alert.alert('خطا', authMethod === 'phone' ? 'لطفاً شماره تلفن را وارد کنید.' : 'لطفاً ایمیل را وارد کنید.');
      return;
    }

    try {
      const fullTarget = authMethod === 'phone' ? `${countryCode}${inputValue}` : inputValue;
      
      const response = await fetch('https://your-api-domain.com/api/auth/forgot-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          target: fullTarget,
          type: authMethod
        }),
      });

      const data = await response.json();

      if (response.ok) {
        Alert.alert('موفقیت', 'کد تایید ارسال شد.');
        setStep(2);
      } else {
        Alert.alert('خطا', data.message || 'خطا در ارسال کد تایید.');
      }
    } catch (error) {
      // حالت آزمایشی برای پیش‌نمایش در Snack
      Alert.alert('تست پیش‌فرض', 'کد تایید به صورت آزمایشی ارسال شد.');
      setStep(2);
    }
  };

  const handleVerifyOTP = async () => {
    if (!otpCode || otpCode.length < 6) {
      Alert.alert('خطا', 'لطفاً کد ۶ رقمی را به طور کامل وارد کنید.');
      return;
    }

    try {
      const fullTarget = authMethod === 'phone' ? `${countryCode}${inputValue}` : inputValue;

      const response = await fetch('https://your-api-domain.com/api/auth/verify-reset-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          target: fullTarget,
          otp: otpCode
        }),
      });

      const data = await response.json();

      if (response.ok) {
        Alert.alert('موفقیت', 'ورود با موفقیت انجام شد!');
      } else {
        Alert.alert('خطا', data.message || 'کد تایید اشتباه یا منقضی شده است.');
      }
    } catch (error) {
      // حالت آزمایشی برای پیش‌نمایش در Snack
      Alert.alert('موفقیت', 'ورود در حالت آزمایشی موفقیت‌آمیز بود!');
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" />
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        <View style={styles.card}>
          <Text style={styles.title}>Blackstarszone</Text>
          <Text style={styles.subtitle}>ورود یا ثبت‌نام حساب کاربر</Text>

          {step === 1 ? (
            <>
              {/* تب انتخاب ایمیل یا تلفن */}
              <View style={styles.tabContainer}>
                <TouchableOpacity
                  style={[styles.tab, authMethod === 'phone' && styles.activeTab]}
                  onPress={() => setAuthMethod('phone')}
                >
                  <Text style={[styles.tabText, authMethod === 'phone' && styles.activeTabText]}>شماره تلفن</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[styles.tab, authMethod === 'email' && styles.activeTab]}
                  onPress={() => setAuthMethod('email')}
                >
                  <Text style={[styles.tabText, authMethod === 'email' && styles.activeTabText]}>ایمیل</Text>
                </TouchableOpacity>
              </View>

              {/* بخش انتخاب پیش‌شماره کشور */}
              {authMethod === 'phone' && (
                <View style={styles.countryPicker}>
                  <Text style={styles.label}>انتخاب پیش‌شماره کشور:</Text>
                  <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.codeList}>
                    {countryCodes.map((item) => (
                      <TouchableOpacity
                        key={item.code}
                        style={[styles.codeBadge, countryCode === item.code && styles.activeCodeBadge]}
                        onPress={() => setCountryCode(item.code)}
                      >
                        <Text style={[styles.codeText, countryCode === item.code && styles.activeCodeText]}>
                          {item.label}
                        </Text>
                      </TouchableOpacity>
                    ))}
                  </ScrollView>
                </View>
              )}

              {/* کادر ورود شماره یا ایمیل */}
              <View style={styles.inputContainer}>
                {authMethod === 'phone' && <Text style={styles.countryPrefix}>{countryCode}</Text>}
                <TextInput
                  style={styles.input}
                  placeholder={authMethod === 'phone' ? '799123456' : 'example@gmail.com'}
                  placeholderTextColor="#64748b"
                  keyboardType={authMethod === 'phone' ? 'phone-pad' : 'email-address'}
                  value={inputValue}
                  onChangeText={setInputValue}
                />
              </View>

              <TouchableOpacity style={styles.button} onPress={handleSendOTP}>
                <Text style={styles.buttonText}>ارسال کد تایید</Text>
              </TouchableOpacity>
            </>
          ) : (
            <>
              {/* بخش ورود کد OTP */}
              <Text style={styles.otpNotice}>
                کد تایید ۶ رقمی به {authMethod === 'phone' ? `${countryCode} ${inputValue}` : inputValue} ارسال شد.
              </Text>

              <TextInput
                style={[styles.input, styles.otpInput]}
                placeholder="------"
                placeholderTextColor="#64748b"
                keyboardType="number-pad"
                maxLength={6}
                value={otpCode}
                onChangeText={setOtpCode}
              />

              <TouchableOpacity style={styles.button} onPress={handleVerifyOTP}>
                <Text style={styles.buttonText}>تایید و ورود</Text>
              </TouchableOpacity>

              <TouchableOpacity onPress={() => setStep(1)} style={styles.backButton}>
                <Text style={styles.backText}>تغییر شماره / ایمیل</Text>
              </TouchableOpacity>
            </>
          )}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0f172a' },
  scrollContainer: { flexGrow: 1, justifyContent: 'center', alignItems: 'center', padding: 20 },
  card: { width: '100%', maxWidth: 400, backgroundColor: '#1e293b', padding: 24, borderRadius: 20, borderWidth: 1, borderColor: '#334155' },
  title: { fontSize: 28, fontWeight: 'bold', color: '#38bdf8', textAlign: 'center' },
  subtitle: { fontSize: 14, color: '#94a3b8', textAlign: 'center', marginBottom: 20, marginTop: 4 },
  tabContainer: { flexDirection: 'row', backgroundColor: '#0f172a', borderRadius: 10, padding: 4, marginBottom: 15 },
  tab: { flex: 1, paddingVertical: 10, alignItems: 'center', borderRadius: 8 },
  activeTab: { backgroundColor: '#2563eb' },
  tabText: { color: '#94a3b8', fontWeight: 'bold' },
  activeTabText: { color: '#ffffff' },
  label: { color: '#94a3b8', fontSize: 12, marginBottom: 8, textAlign: 'right' },
  countryPicker: { marginBottom: 15 },
  codeList: { flexDirection: 'row-reverse' },
  codeBadge: { backgroundColor: '#0f172a', paddingHorizontal: 12, paddingVertical: 8, borderRadius: 8, marginLeft: 8, borderWidth: 1, borderColor: '#334155' },
  activeCodeBadge: { backgroundColor: '#2563eb', borderColor: '#38bdf8' },
  codeText: { color: '#94a3b8', fontSize: 12 },
  activeCodeText: { color: '#ffffff', fontWeight: 'bold' },
  inputContainer: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#0f172a', borderRadius: 10, borderWidth: 1, borderColor: '#334155', marginBottom: 20, paddingHorizontal: 12 },
  countryPrefix: { color: '#38bdf8', fontWeight: 'bold', marginRight: 8 },
  input: { flex: 1, color: '#ffffff', paddingVertical: 12, fontSize: 16, textAlign: 'right' },
  otpInput: { textAlign: 'center', letterSpacing: 8, fontSize: 22 },
  button: { backgroundColor: '#2563eb', paddingVertical: 14, borderRadius: 10, alignItems: 'center' },
  buttonText: { color: '#ffffff', fontWeight: 'bold', fontSize: 16 },
  otpNotice: { color: '#94a3b8', textAlign: 'center', marginBottom: 15, fontSize: 13 },
  backButton: { marginTop: 15, alignItems: 'center' },
  backText: { color: '#38bdf8', fontSize: 13 },
});
